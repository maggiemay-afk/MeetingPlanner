from django.contrib import admin
from .models import Meeting

# Register your models here.
admin.site.register(Meeting)