from datetime import datetime
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.


def welcome(request):
    return HttpResponse("Welcome to my website!")


def date(request):
    return HttpResponse("This page was served at: " + str(datetime.now()))


def about(request):
    return HttpResponse("This is a website created by Maggie Herms for APC440")
